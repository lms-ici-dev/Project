Zip Berisi : 

- Design figma yang telah direvisi (Tinjauan lebih lanjut sangat dianjurkan

File dapat di import ke figma untuk dilihat dengan meng-import ke applikasi/web-app figma 




Link untuk Use cases dan boards alur pengerjaan project pada miro :

https://miro.com/app/board/o9J_lUY8-cs=/?fromRedirect=1




Scheduling dapat dilihat pada jira-app dengan link berikut :

https://rms-tri.atlassian.net/jira/software/projects/CTCI/boards/1/roadmap

Notes : Untuk tim RMS, backlog belum tersedia, sehingga belum bisa melihat report sprint



Atau silahkan kontak Admin bersangkutan :
Ahmad Nugroho
